package gradleExample;

public class HelloWorld {

    public static void main(String[] args) {

        Greeter gretter = new Greeter();
        System.out.println(gretter.sayHello());
    }
}
