/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex5_maven;

/**
 *
 * @author PC
 */
public class Book<T1, T2> extends Media<T1,T2> {


    public Book(T2 T2, T1 name) {
        super(name,T2);
    }

    
    
    
}
