/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package test_parte2;

import java.awt.Point;
import java.util.ArrayList;

/**
 *
 * @author PC
 */
public class TEST_Parte2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        /*
        Point[] a = new Point[10];
        Object[] b;
        b = a;
        b[0] = new Point(10, 20);
        
        System.out.println(b[0].toString());
         */
 /*
        Point[] a = new Point[10];
        Object[] b;
        b = a;
        b[0] = "magical Mystery Tour";
        
        System.out.println(b[0].toString());
         */
 /*Point[] a = new Point[10];
        Object[] b;
        b = a;
        

        System.out.println(a);
        System.out.println(b);
         */
        ArrayList<Point> a = new ArrayList<Point>();
        ArrayList<Object> b = new ArrayList<Object>();

        b=a;
        
    }

}
