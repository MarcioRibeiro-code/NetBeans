/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex2_parte1;

/**
 *
 * @author PC
 */
public class EX2_Parte1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Pair<Integer> p = new Pair<Integer>(1, 2);
        System.out.println(p.max());
// TODO code application logic here
    }

}
