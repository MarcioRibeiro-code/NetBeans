public class EX2{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        System.out.println("Soma: " + (Double.parseDouble(args[0]) + Double.parseDouble(args[1])));
        System.out.println("Subtração: " + (Double.parseDouble(args[0]) - Double.parseDouble(args[1])));
        System.out.println("Multiplicacao: " + (Double.parseDouble(args[0]) * Double.parseDouble(args[1])));
        System.out.println("Divisao: " + (Double.parseDouble(args[0]) / Double.parseDouble(args[1])));

    }

}