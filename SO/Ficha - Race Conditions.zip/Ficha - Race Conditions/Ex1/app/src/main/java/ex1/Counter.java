package ex1;
public class Counter{
    long count =0;

    
    /** 
     * Increments the counter with the given value.
     * @param value value to add to the counter
     */
    public  void  add(long value){
        this.count += value;
    }
}

